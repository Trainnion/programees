to run python file on pc. download python on their website.

to run html, open "index.html" in your browser
